var docsearch = require('docsearch.js/dist/cdn/docsearch.js');
docsearch({
	appId: 'D1BPLZHGYQ',
	apiKey: '6df94e1e5d55d258c56f60d974d10314',
	indexName: 'hugodocs',
	inputSelector: '#search-input',
	debug: true, // Set debug to true if you want to inspect the dropdown
});
