---
title: echoParam
description: Prints a parameter if it is set.
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: []
signature: ["echoParam DICTIONARY KEY"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
draft: false
aliases: []
---


```
{{ echoParam .Params "project_url" }}
```
