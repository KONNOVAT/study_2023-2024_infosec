---
title: strings.FirstUpper
description: Capitalizes the first character of a given string.
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [strings capitalize uppercase first]
signature: ["strings.FirstUpper STRING"]
hugoversion:
aliases: []
---

    {{ strings.FirstUpper "foo" }} → "Foo"
